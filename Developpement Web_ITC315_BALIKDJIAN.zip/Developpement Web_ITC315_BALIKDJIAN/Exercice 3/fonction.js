
function testFonctionnalites() {

    /*test si geolocalisation est active sur le navigateur.*/
    document.querySelector("#geoloc").innerHTML = Modernizr.geolocation ? "pris en charge" : "non pris en charge";
    

    /*test si le navigateur à un ecran tactile actif, donc si l'on est sur téléphone.*/
    document.querySelector("#touch").innerHTML = Modernizr.touch ? "pris en charge" : "non pris en charge";
    

    /* test si les images SVG sont prise en charge sur le navigateur.*/
    document.querySelector("#svg").innerHTML = Modernizr.svg ? "pris en charge" : "non pris en charge";
    

    /*test si les animations Canvas sont prise en charge sur le navigateur.*/
    document.querySelector("#canvas").innerHTML = Modernizr.canvas ? "pris en charge" : "non pris en charge";
    


}
window.onload = testFonctionnalites;


