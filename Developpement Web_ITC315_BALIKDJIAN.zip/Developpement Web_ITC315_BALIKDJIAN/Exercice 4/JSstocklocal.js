function initialize() {
    /*on cherche si l'API est géré par le navigateur. */
    var bSupportsLocal = (('localStorage' in window) && window['localStorage'] !== null);

    /* indique si le stockage local est possible.*/
    if (!bSupportsLocal) {
        document.getElementById('infoform').innerHTML = "<p>Désolé, ce navigateur ne supporte pas l’API Web Storage du W3C.</p>";
        return;
    }

    /* Si le stockage local contient déjà des données on remplis le formulaire avec ces données. */
    if (window.localStorage.length != 0) {
        document.getElementById('firstName').value = window.localStorage.getItem('firstName');
        document.getElementById('lastName').value = window.localStorage.getItem('lastName');
        document.getElementById('postCode').value = window.localStorage.getItem('postCode');
    }  
}

/*stocke les données dans le stockage local du navigateur.
la fonction est exécuté lorsque le formulaire est validé en cliquant sur le bouton enregistrer*/
function storeLocalContent(fName, lName, pCode) {
    window.localStorage.setItem('firstName', fName);
    window.localStorage.setItem('lastName', lName);
    window.localStorage.setItem('postCode', pCode);
}

/*nettoie le stockage local du navigateur */
function clearLocalContent(fName, lName, pCode) {
    window.localStorage.clear(); //vide le stockage local du navigateur
}

window.onload = initialize;





